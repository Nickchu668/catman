<?php
/**
 * 獲取指定日期的調查數據
 */
function getSurveyData($date) {
    $dataDir = __DIR__ . '/../data';
    $filename = $dataDir . '/' . $date . '.txt';
    
    if (!file_exists($filename)) {
        return [];
    }
    
    $lines = file($filename, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $data = [];
    
    foreach ($lines as $line) {
        $parts = explode('|', $line, 2);
        if (count($parts) === 2) {
            $data[] = [
                'time' => $parts[0],
                'answer' => $parts[1]
            ];
        }
    }
    
    return $data;
}

/**
 * 統計答案頻率
 */
function getAnswerStats($data) {
    $stats = [];
    
    foreach ($data as $entry) {
        $answer = trim(strtolower($entry['answer']));
        
        if (isset($stats[$answer])) {
            $stats[$answer]['count']++;
        } else {
            $stats[$answer] = [
                'original' => $entry['answer'],
                'count' => 1
            ];
        }
    }
    
    // 按頻率排序
    uasort($stats, function($a, $b) {
        return $b['count'] - $a['count'];
    });
    
    return $stats;
}

/**
 * 獲取所有可用的日期
 */
function getAvailableDates() {
    $dataDir = __DIR__ . '/../data';
    $dates = [];
    
    if (is_dir($dataDir)) {
        $files = scandir($dataDir);
        foreach ($files as $file) {
            if (preg_match('/^(\d{4}-\d{2}-\d{2})\.txt$/', $file, $matches)) {
                $dates[] = $matches[1];
            }
        }
    }
    
    // 按日期倒序排列
    rsort($dates);
    
    return $dates;
}

/**
 * 計算泡泡大小（基於頻率）
 */
function calculateBubbleSize($count, $maxCount) {
    $minSize = 60;
    $maxSize = 200;
    
    if ($maxCount <= 1) {
        return $minSize;
    }
    
    $ratio = $count / $maxCount;
    return $minSize + ($maxSize - $minSize) * $ratio;
}

/**
 * 生成隨機顏色
 */
function generateBubbleColor($index) {
    $colors = [
        '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7',
        '#DDA0DD', '#98D8C8', '#F7DC6F', '#BB8FCE', '#85C1E9',
        '#F8C471', '#82E0AA', '#F1948A', '#85C1E9', '#D7BDE2'
    ];
    
    return $colors[$index % count($colors)];
}
?>

